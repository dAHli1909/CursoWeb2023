﻿Typeface © (xdCreative). <2021>. All Rights Reserved 
@faldykudo

Hello, please contact me before use this font as commercial use. 
My fonts for free use allowed only in personal project , non-profit and charity use. 
If you make money from using my fonts, Please purchase a commercial license
here :  https://www.myfonts.com/foundry/xdcreative/


find me on instagram @faldykudo

___________________________________________________________________________

SOFTWARE REQUIREMENTS :

The fonts can be opened and used in any software that can read standard fonts - even MS Word. 
No special software is required , and a friendly little help file is included to get you started :

Opentype capable software : The alternates are accessible by turning on 
"Stylistic Alternates" and "Ligatures" buttons on in Photoshop's Character panel, 
or via any software with a glyphs panel, e.g. Adobe Illustrator, Photoshop CC, Inkscape.

_______________________________________________________________________________________

NOTES: PELANGGARAN DAN PENYALAHGUNAAN FONT INI AKAN DIKENAKAN HUKUM DAN DENDA SESUAI UNDANG-UNDANG. 
(DENDA MINIMAL 10X HARGA CORPORATE LICENSE)

support and donation

https://paypal.me/FadilAbdillah

Thank you



Regad.